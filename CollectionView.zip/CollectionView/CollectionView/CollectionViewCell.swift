//
//  CollectionViewCell.swift
//  alertController
//
//  Created by Egor Devyatov on 20/08/2019.
//  Copyright © 2019 Egor Devyatov. All rights reserved.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var collectionCellLabel: UILabel!
    
    
}
